<?php
/**************************************************************************************************
| Codehaivl
| http://www.Codehaivl.com
| codehaivl@gmail.com
|
|**************************************************************************************************
|
| By using this software you agree that you have read and acknowledged our End-User License 
| 
|
| Copyright (c) Codehaivl.com. All rights reserved.
|**************************************************************************************************/
$sban = "1";
include("include/config.php");
//TEMPLATES BEGIN
STemplate::display("banned.tpl");
//TEMPLATES END
?>