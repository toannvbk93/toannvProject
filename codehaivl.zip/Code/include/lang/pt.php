<?
$lang = array();

$lang['0'] = "username e senha primeiro.";
$lang['1'] = "Nome";
$lang['2'] = "Senha";
$lang['3'] = "Next";
$lang['4'] = "Erro: Digite seu nome de usuário";
$lang['5'] = "Erro: Por favor, digite sua senha";
$lang['6'] = "Erro:. O nome de usuário que você escolheu já está tomada";
$lang['7'] = "Nome de usuário pode conter apenas letras AZ e os números de 0-9.";
$lang['8'] = "Seu nome de usuário deve ter pelo menos dois caracteres";
$lang['9'] = "Registe-se agora a explorar novos conteúdos";
$lang['10'] = "possui uma conta?";
$lang['11'] = "Entrar";
$lang['12'] = "Bem-vindo ao melhor lugar para se divertir.";
$lang['13'] = "e votar em seus favoritos";
$lang['14'] = "Registe-se com o Facebook";
$lang['15'] = "Nós nunca vamos publicar sem sua permissão.";
$lang['16'] = "Eu não tenho uma conta no Facebook";
$lang['17'] = "Obrigado por sua inscrição!";
$lang['18'] = "Nós enviaremos um convite assim que pudermos.";
$lang['19'] = "Obrigado por registro, vá se divertir agora!";
$lang['20'] = "E-mail";
$lang['21'] = "Seu e-mail";
$lang['22'] = "Convite Pedido";
$lang['23'] = "Novo?";
$lang['24'] = "Join!";
$lang['25'] = "Login Facebook";
$lang['26'] = "Erro:. Seu nome de usuário ou senha está errada";
$lang['27'] = "Voltar ao login";
$lang['28'] = "Esqueceu";
$lang['29'] = "Enviar";
$lang['30'] = "Erro:. Sua conta não está ativa";
$lang['31'] = "Se existe uma conta com esse endereço de e-mail um e-mail será enviado com o acesso à conta.";
$lang['32'] = "Obrigado";
$lang['33'] = "Lembrete de Senha";
$lang['34'] = "Recebemos uma solicitação de senha esquecida para você conta:";
$lang['35'] = "Sua senha:";
$lang['36'] = "Nome de usuário ou e-mail";
$lang['37'] = "Erro: Seu e-mail ou senha está errada";
$lang['38'] = "Seu Convite";
$lang['39'] = "Bem vindo";
$lang['40'] = "Sua senha é";
$lang['41'] = "Não se esqueça de mudá-lo após acessar sua conta.";
$lang['42'] = "Você precisa selecionar um nome de usuário depois log in";
$lang['43'] = "Você pode ir e se divertir agora!";
$lang['44'] = "Bem-vindo ao";
$lang['45'] = "Configurações";
$lang['46'] = "Erro:. Por favor, digite seu e-mail address";
$lang['47'] = "Erro:. O seu endereço de e-mail não é válido";
$lang['48'] = "Erro:. O endereço de e-mail inserido já está em uso";
$lang['49'] = "Erro:. Por favor, digite a nova senha";
$lang['50'] = "Erro:. Por favor, confirme sua nova senha";
$lang['51'] = "Erro:. Sua nova senha e confirme a senha não corresponde";
$lang['52'] = "Sucesso:. Suas configurações foram salvas";
$lang['53'] = "Perfil Pic";
$lang['54'] = "JPEG, GIF ou PNG Tamanho máximo:.. 2MB";
$lang['55'] = "Remover avatar";
$lang['56'] = "suas cores";
$lang['57'] = "Cor do seu perfil";
$lang['58'] = "Cor de links";
$lang['59'] = "Nome Completo";
$lang['60'] = "Seu nome completo aparecerá no seu perfil público";
$lang['61'] = "Seu email não será exibido publicamente.";
$lang['62'] = "Localização & Language";
$lang['63'] = "Por favor seleccione o seu país";
$lang['64'] = "Por favor, Selecione";
$lang['65'] = "De onde você é?";
$lang['66'] = "Idioma Padrão";
$lang['67'] = "About";
$lang['68'] = "Bio";
$lang['69'] = "Seja breve e interessante.";
$lang['70'] = "Website";
$lang['71'] = "Tenha uma página ou um blog Coloque a URL aqui?";
$lang['72'] = "Nova senha";
$lang['73'] = "Confirmar nova senha";
$lang['74'] = "Avisos";
$lang['75'] = "Enviar e-mail as atualizações do site me!";
$lang['76'] = "Excluir Conta";
$lang['77'] = "Salvar";
$lang['78'] = "Excluir a sua conta";
$lang['79'] = "Esta ação é permanente.";
$lang['80'] = "Tem certeza de que não quer reconsiderar?";
$lang['81'] = "Foi algo que nós dissemos?";
$lang['82'] = "Diga-nos.";
$lang['83'] = "Sua senha é necessária para confirmar esta acção.";
$lang['84'] = "Erro:. Sua senha é errado";
$lang['85'] = "Confirmar o seu endereço de e-mail";
$lang['86'] = "Por favor, clique no link a seguir para confirmar seu endereço de e-mail";
$lang['87'] = "Obrigado";
$lang['88'] = "Erro:. Seu código de confirmação de e-mail está errado";
$lang['89'] = "Erro:. O seu endereço de e-mail já está verificado";
$lang['90'] = "Sucesso:. O seu endereço de e-mail foi confirmado";
$lang['91'] = "Awww Sim Bem-vindo de volta!";
$lang['92'] = "Você está banido.";
$lang['93'] = "Erro:. Por favor, selecione uma imagem para upload";
$lang['94'] = "Erro:. Seu formato de imagem não é suportado";
$lang['95'] = "Erro:. Digite um título";
$lang['96'] = "Erro:. Digite um url de imagem válido";
$lang['97'] = "Erro:. Não foi possível baixar a sua foto a partir do URL";
$lang['98'] = "Erro:. Digite um url de vídeo";
$lang['99'] = "Erro: Você deve digitar uma URL de vídeo do youtube.com ou funnyordie.com";
$lang['100'] = "Pic";
$lang['101'] = "Vídeo";
$lang['102'] = "Adicionar um pic engraçado";
$lang['103'] = "Arquivo Pic";
$lang['104'] = "URL Pic";
$lang['105'] = "Enviar um arquivo";
$lang['106'] = "Use um URL.";
$lang['107'] = "Os formatos aceitos são JPEG, GIF ou PNG.";
$lang['108'] = "Adicionar um vídeo engraçado";
$lang['109'] = "URL do vídeo";
$lang['110'] = "Atualmente nós só damos suporte YouTube e vídeos Funny or Die.";
$lang['111'] = "Título da Mensagem";
$lang[112] = "Um título descritivo ou interessante vai atrair mais votos e partilhas.";
$lang['113'] = "Tags";
$lang['114'] = "opcional";
$lang['115'] = "Via Source /";
$lang['116'] = "Respeito originalidade e criatividade.";
$lang['117'] = "Este é NSFW (não seguro para o trabalho).";
$lang['118'] = "Use vírgula para separar cada tag projeto Eg, wtf, impressionante.";
$lang['119'] = "Cancelar";
$lang['120'] = "Adicionar";
$lang['121'] = "Enviar Quota";
$lang['122'] = "mensagens podem ser enviadas todos os dias";
$lang['123'] = "Regras de submissão";
$lang['124'] = "Por favor, sem fotos, fotos hipster seu Facebook, nem qualquer outro conteúdo sem graça Esta é uma comunidade de apenas diversão..";
$lang['125'] = "Respeito originalidade e criatividade.";
$lang['126'] = "Tente usar o Google Images para encontrar a origem do post.";
$lang['127'] = "Pense em um título descritivo ou criativo, em vez de LOL, True, :) ou se ... então f ** k você.";
$lang['128'] = "Pesquisar dupes antes de postar mensagens duplicadas serão removidas.";
$lang['129'] = "Obter este para a página Hot é pior do que como esta L / Imprensa e ambos serão removidos.";
$lang['130'] = "Não blogspam Muitos, muitos sites apenas reciclar as fotos de outros sites e colocar anúncios sobre ele.";
$lang['131'] = "Se você hesita em mostrar o conteúdo de seus colegas de trabalho, sua mãe, ou tio Bob, por favor, marque-o como NSFW.";
$lang['132'] = "posts NSFW será removido se não for marcado como tal.";
$lang['133'] = "[Fixado] posts deve ser adicionado usando o botão Corrigir este post.";
$lang['134'] = "Certifique-se de ter verificado a nossa";
$lang['135'] = "9 Regras";
$lang['136'] = "tldr";
$lang['137'] = "Ajuda-nos a ser o melhor lugar de diversão!";
$lang['138'] = "Erro:. Pós desconhecido";
$lang['139'] = "Erro:. Não é possível localizar pós especificado";
$lang['140'] = "Este post está sendo moderado.";
$lang['141'] = "origem desconhecida";
$lang['142'] = "Corrigir este post";
$lang['143'] = "Comentários";
$lang['144'] = "Love";
$lang['145'] = "Excluir";
$lang['146'] = "post Relatório";
$lang['147'] = "Por favor, confirme que deseja excluir este post.";
$lang['148'] = "Y U Não Inscrição?";
$lang['149'] = "Follow";
$lang['150'] = "Recomendar no Google";
$lang['151'] = "Hey ...";
$lang['152'] = "Pressione Ctrl + D ou ⌘ + D (se você estiver usando Mac) para ver a magia acontece!";
$lang['153'] = "Mostre seu amor";
$lang['154'] = "Como o sistema funciona";
$lang['155'] = "Este post pode conter conteúdo impróprio para alguns usuários, como sinalizado por nossa comunidade de usuários.";
$lang['156'] = "Desativar o Modo de Segurança para ver";
$lang['157'] = "1 segundo atrás";
$lang['158'] = "segundos atrás";
$lang['159'] = "1 minuto atrás";
$lang['160'] = "minutos";
$lang['161'] = "1 hora atrás";
$lang['162'] = "horas";
$lang['163'] = "dias atrás";
$lang['164'] = "dias atrás";
$lang['165'] = "Comentário";
$lang['166'] = "mais recente";
$lang['167'] = "Older";
$lang['168'] = "Usar Script Clone 9GAG como um chefe!";
$lang['169'] = "Tip";
$lang['170'] = "Pressione o' J 'e' K 'teclas para navegar rapidamente através de mensagens.";
$lang['171'] = "Tip-Press-2";
$lang['172'] = "quente";
$lang['173'] = "Tendências";
$lang['174'] = "Vote";
$lang['175'] = "Opa Você não é elegível para visualizar a página Vote!";
$lang['176'] = "Para preservar a qualidade dos posts Script 9GAG Clone, apenas 9GAG Scripters Clone tem permissão para ver a página.";
$lang['177'] = "ler isso para saber como funciona 9GAG Script Clone";
$lang['178'] = "e";
$lang['179'] = "Sign Up Now!";
$lang['180'] = "desamor";
$lang['181'] = "Não basta anexar uma mensagem de texto, um rosto meme ou raiva (por exemplo, não é mau, B * tch por favor, GTFO, Aliens ...) para os posts originais. Eles não são considerados como [Corrigido] mensagens e será removido. ";
$lang['182'] = "Se você tem uma mensagem ou discorda das mensagens originais, expressar sua opinião nos comentários.";
$lang['183'] = "Erro:. O post você tentar corrigir não existe";
$lang['184'] = "Etapa 1:";
$lang['185'] = "Botão direito do mouse e salvar a imagem em seu computador";
$lang['186'] = "Passo 2:";
$lang['187'] = "Corrigir e fazer o upload";
$lang['188'] = "Erro:. Você chegou a sua cotação de upload para hoje, tente novamente amanhã";
$lang['189'] = "Pesquisar";
$lang['190'] = "Digite palavras para buscar";
$lang['191'] = "resultado foi encontrado";
$lang['192'] = "Mensagens";
$lang['193'] = "Likes";
$lang['194'] = "Mensagens";
$lang['195'] = "Diga alguma coisa";
$lang['196'] = "Shuffle";
$lang['197'] = "Login";
$lang['198'] = "Sair";
$lang['199'] = "Upload";
$lang['200'] = "Fast";
$lang['201'] = "Fun";
$lang['202'] = "FAQ";
$lang['203'] = "Termos de Uso";
$lang['204'] = "Política de Privacidade";
$lang['205'] = "Contato";
$lang['206'] = "Relatório";
$lang['207'] = "Por que você está reportando este post?";
$lang['208'] = "Contém uma violação de marca registrada ou direitos de autor";
$lang['209'] = "Spam, publicidade descarada, ou solicitação";
$lang['210'] = "Contém materiais ofensivos / nudez";
$lang['211'] = "Repost de um outro post";
$lang['212'] = "Enviar";
$lang['213'] = "9GAG Clone Atalhos de teclado Script";
$lang['214'] = "random";
$lang['215'] = "comentário";
$lang['216'] = "ódio";
$lang['217'] = "next";
$lang['218'] = "anterior";
$lang['219'] = "como";
$lang['220'] = "Clique em qualquer lugar para fechar";
$lang['221'] = "Update";
$lang['222'] = "Idiomas";
$lang['223'] = "Escolha o seu idioma";
$lang['224'] = "Erro: Não foi possível registrá-lo dentro";
$lang['225'] = "Erro:. Sua conta não está ativa";
$lang['226'] = "Antes de nos contactar, por favor, vá para a FAQ.";
$lang['227'] = "Assunto";
$lang['228'] = "Select";
$lang['229'] = "Reportar um bug";
$lang['230'] = "Faça uma pergunta";
$lang['231'] = "Enviar comentários";
$lang['232'] = "inquérito Negócios";
$lang['233'] = "Assunto";
$lang['234'] = "Sua solicitação em uma frase.";
$lang['235'] = "Mensagem";
$lang['236'] = "Quanto mais detalhes você fornecer, mais fácil para nós para ajudá-lo.";
$lang['237'] = "Seu Nome";
$lang['238'] = "Email";
$lang['239'] = "O e-mail que podemos alcançá-lo.";
$lang['240'] = "O seu sistema operacional";
$lang['241'] = "por exemplo, Windows 7, Mac OS X Lion";
$lang['242'] = "Código da Imagem";
$lang['243'] = "Erro: Por favor seleccione um tópico";
$lang['244'] = "Erro: Por favor insira um assunto";
$lang['245'] = "Erro: Por favor, escreva a sua mensagem";
$lang['246'] = "Erro: Digite seu nome";
$lang['247'] = "Erro:. código da imagem errado, por favor tente novamente";
$lang['248'] = "Sucesso:. Sua mensagem foi enviada";
$lang['249'] = "9Gag Clone Formulário de Contato Script";
$lang['250'] = "O usuário acaba de enviar-lhe as seguintes informações através do formulário de contato on-line:";
$lang['251'] =  "Recommended";
$lang['252'] =  "Sign up with Twitter";
$lang['253'] =  "Please enter your email to finish registration.";
$lang['254'] =  "en";
$lang['255'] =  "LTR";
$lang['256'] =  "Sign in with Twitter";
$lang['257'] =  "Hello,";
$lang['258'] =  "Thumb View";
$lang['259'] =  "List View";
$lang['260'] =  "Top Users";
$lang['261'] =  "Previous";
$lang['262'] =  "Next";
$lang['263'] =  "Sorry, but fixing gags is currently disabled";
$lang['264'] =  "There's something wrong with this gag, please report it via our contact form";
$lang['265'] =  "Finish Registration";
$lang['266'] =  "Awwwwwwww Yeah!";
$lang['267'] =  "You've done that! Your post is shown on the&nbsp;<a href=\"/vote\" target=\"_blank\">Vote</a>&nbsp;page. Now get more votes by sharing the fun with your friends!";
$lang['268'] =  "Paste link in <b>email</b> or <b>IM</b>";
$lang['269'] =  "Channel";
$lang['270'] =  "Please select post channel";
$lang['271'] =  "Choose the closest Channel/Category to your post";
$lang['272'] =  "Top Channels";
$lang['273'] =  "";
?>