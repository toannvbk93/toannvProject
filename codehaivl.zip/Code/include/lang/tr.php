<?
$lang = array();

$lang['0'] = "ilk oluşturun kullanıcı adı ve parola.";
$lang['1'] = "Kullanıcı adı";
$lang['2'] = "Parola";
$lang['3'] = "Sonraki";
$lang['4'] = "Hata: kullanıcı adınızı girin";
$lang['5'] = "Hata: Lütfen şifrenizi girin";
$lang['6'] = "Hata:. Seçtiğiniz kullanıcı adı önceden alınmış";
$lang['7'] = "Kullanıcı adı sadece harf ve rakam 0-9 AZ içerebilir.";
$lang['8'] = "Kullanıcı adınız en az iki karakter olmalı";
$lang['9'] = "yeni içerik keşfetmek için şimdi kaydolun";
$lang['10'] = "bir hesabı var mı?";
$lang['11'] = "Oturum aç";
$lang['12'] = "eğlence için en iyi yere geldiniz.";
$lang['13'] = "ve favorilerini oy";
$lang['14'] = "Facebook ile kaydolun";
$lang['15'] = "Sizin izniniz olmadan göndermek asla.";
$lang['16'] = "Ben bir Facebook hesabım yok";
$lang['17'] = "kadar oturum açma için teşekkürler!";
$lang['18'] = "Biz en kısa sürede size bir davet göndereceğiz.";
$lang['19'] = "Kayıt için teşekkürler, şimdi biraz eğlenelim git!";
$lang['20'] = "E-posta";
$lang['21'] = "E-posta adresiniz";
$lang['22'] = "İstek Davet";
$lang['23'] = "Yeni";
$lang['24'] = "Bugün katılın!";
$lang['25'] = "Facebook ile Giriş";
$lang['26'] = "Hata:. Kullanıcı adı veya şifre yanlış";
$lang['27'] = "giriş Geri";
$lang['28'] = "unuttum";
$lang['29'] = "Gönder";
$lang['30'] = "Hata:. Hesabınız etkin değil";
$lang['31'] = "bir hesap e-posta adresi ile varsa bir e-posta hesabına erişim ile gönderilecektir.";
$lang['32'] = "Thank You";
$lang['33'] = "Şifre Hatırlatma";
$lang['34'] = "Biz size hesap için bir şifremi unuttum isteği aldı:";
$lang['35'] = "Şifrenizi:";
$lang['36'] = "Kullanıcı adı veya E-posta";
$lang['37'] = "Hata:. E-posta veya şifre yanlış";
$lang['38'] = "Sizin Davet";
$lang['39'] = "Hoşgeldiniz";
$lang['40'] = "Parolanız olduğunu";
$lang['41'] = "Oturum sonra bunu değiştirmek için unutmayın.";
$lang['42'] = "Oturum açtıktan sonra bir kullanıcı adı seçmeniz gerekecektir";
$lang['43'] = "Sen git ve şimdi bazı eğlenceli olabilir!";
$lang['44'] = "Hoş Geldiniz";
$lang['45'] = "Ayarlar";
$lang['46'] = "Hata:. E-posta adresinizi girin";
$lang['47'] = "Hata:. E-posta adresi geçerli değil";
$lang['48'] = "Hata:. Girdiğiniz e-posta adresi zaten kullanılıyor";
$lang['49'] = "Hata:. Yeni şifrenizi giriniz";
$lang['50'] = "Hata:. Yeni şifrenizi teyit edin";
$lang['51'] = "Hata:. Yeni parola ve şifre onaylayın uymuyor";
$lang['52'] = "Başarı:. Ayarlarınız kaydedildi";
$lang['53'] = "Profil Pic";
$lang['54'] = "JPEG, GIF ya da PNG Maksimum boy:.. 2MB";
$lang['55'] = "avatar Kaldır";
$lang['56'] = "Sizin Renkleri";
$lang['57'] = "profilinizin Renk";
$lang['58'] = "bağlantıları Renk";
$lang['59'] = "Tam Adı";
$lang['60'] = "Adınız ve soyadınız Genel profilinizde görünür";
$lang['61'] = "E-posta adresiniz kamuya gösterilmeyecektir.";
$lang['62'] = "Yer ve Dil";
$lang['63'] = "Lütfen ülkenizi seçin";
$lang['64'] = "Seçiniz";
$lang['65'] = "Nerelisin?";
$lang['66'] = "Varsayılan dil";
$lang['67'] = "Hakkında";
$lang['68'] = "Bio";
$lang['69'] = "kısa ve ilginç olun.";
$lang['70'] = "Web Sitesi";
$lang['71'] = "Bir Web Sitesini veya bir blog var URL'yi buraya koy?.";
$lang['72'] = "Yeni Şifre";
$lang['73'] = "Yeni Şifre Tekrar";
$lang['74'] = "Bildirimler";
$lang['75'] = "Bana web sitesi güncellemeleri E-posta!";
$lang['76'] = "Hesabı sil";
$lang['77'] = "Kaydet";
$lang['78'] = "Bu hesabı sil";
$lang['79'] = "Bu eylem kalıcıdır.";
$lang['80'] = "Eğer yeniden istemiyorum emin misin?";
$lang['81'] = "biz söylediğin bir şey miydi?";
$lang['82'] = "bize bildirin.";
$lang['83'] = "Parolanız, bu eylemi onaylamak için gereklidir.";
$lang['84'] = "Hata:. Parolanız yanlış";
$lang['85'] = "e-posta adresinizi doğrulayın";
$lang['86'] = "e-posta adresinizi onaylamak için aşağıdaki linke tıklayınız";
$lang['87'] = "Thank You";
$lang['88'] = "Hata:. E-posta onay kodu yanlış";
$lang['89'] = "Hata:. E-posta adresi zaten doğrulanır";
$lang['90'] = "Başarı:. E-posta adresinizi teyit edilmiştir";
$lang['91'] = "Evet Ahh Tekrar hoş geldiniz!.";
$lang['92'] = "Sen yasaklandı.";
$lang['93'] = "Hata:. Yüklemek için bir resim seçiniz";
$lang['94'] = "Hata:. Sizin görüntü biçimi desteklenmiyor";
$lang['95'] = "Hata:. Bir başlık giriniz";
$lang['96'] = "Hata:. Geçerli bir resim url girin";
$lang['97'] = "Hata:. Url fotoğraf yüklenemiyor";
$lang['98'] = "Hata:. Bir video url girin";
$lang['99'] = "Hata: YouTube.com veya funnyordie.com bir video url girmelisiniz";
$lang['100'] = "Resim";
$lang['101'] = "Video";
$lang['102'] = "komik bir pic ekle";
$lang['103'] = "Resim Dosyası";
$lang['104'] = "Resim URL";
$lang['105'] = "bir dosya yükleyin.";
$lang['106'] = "bir URL kullanın.";
$lang['107'] = "Kabul formatları JPEG, GIF ya da PNG.";
$lang['108'] = "komik bir video ekle";
$lang['109'] = "Video URL";
$lang['110'] = "Şu anda sadece YouTube ve Funny or Die videolar destekliyoruz.";
$lang['111'] = "Yazı Başlığı";
$lang['112'] = "açıklayıcı ya da ilginç bir başlık daha fazla oy ve paylaşımlar çekecek.";
$lang['113'] = "Etiketler";
$lang['114'] = "isteğe bağlı";
$lang['115'] = "Via / Kaynak";
$lang['116'] = "Saygı özgünlük ve yaratıcılık.";
$lang['117'] = "Bu NSFW (İş İçin Güvenli Değil)' dir.";
$lang['118'] = "Her etiketi ayırmak için virgül kullanın Örneğin tasarım, wtf, harika..";
$lang['119'] = "İptal";
$lang['120'] = "Ekle";
$lang['121'] = "Kota Yükle";
$lang['122'] = "mesajları her gün yüklenebilir";
$lang['123'] = "Gönderme Kuralları";
$lang['124'] = "Lütfen, hayır hipster çekim, sizin Facebook fotoğrafları ne de başka bir unfunny içeriği Bu SADECE FUN bir topluluktur..";
$lang['125'] = "Saygı özgünlük ve yaratıcılık.";
$lang['126'] = "post kökenini bulmak için Google Images kullanmayı deneyin.";
$lang['127'] = "yerine LOL, bir açıklayıcı ya da yaratıcı başlık düşünün, Doğru, :) ya eğer ... o zaman f ** k.";
$lang['128'] = "göndermeden önce dupes ara Duplicate mesaj silinecektir..";
$lang['129'] = "Sıcak sayfasına bu alın bu / Basın L gibi daha kötü hem de silinecektir dedi.";
$lang['130'] = "Hayır blogspam çok, pek çok site sadece diğer sitelerden resimleri geri dönüşüm ve reklam koydu..";
$lang['131'] = "Eğer iş arkadaşlarınıza içeriğini göstermek için tereddüt ediyorsanız, annen veya amcanız, NSFW olarak işaretlenmesi gerekmektedir.";
$lang['132'] = "gibi işaretli değilse NSFW mesaj silinecektir.";
$lang['133'] = "[Sabit] Mesajları Fix kullanarak bu yazı butonu eklenmelidir.";
$lang['134'] = "Eğer bizim kontrol emin olun";
$lang['135'] = "9 Kuralları";
$lang['136'] = "tldr";
$lang['137'] = "bize eğlenceli iyi yer için yardım edin!";
$lang['138'] = "Hata:. Bilinmeyen yazılan";
$lang['139'] = "Hata:. Belirtilen mesaj bulunamıyor";
$lang['140'] = "Bu mesaj şu moderatörlüğünü ediliyor.";
$lang['141'] = "bilinmeyen bir kaynak";
$lang['142'] = "Bu yazı Fix";
$lang['143'] = "Yorumlar";
$lang['144'] = "Aşk";
$lang['145'] = "Sil";
$lang['146'] = "Rapor sonrası";
$lang['147'] = "Eğer bu yazı silmek istediğinizi onaylayın.";
$lang['148'] = "Y U Kayıt yok!";
$lang['149'] = "Takip";
$lang['150'] = "Google hakkında Recommend";
$lang['151'] = "Hey ...";
$lang['152'] = "Ctrl + D veya ⌘ + D sihirli olur görmek için (Mac kullanıyorsanız)";
$lang['153'] = "aşkını gösterme";
$lang['154'] = "Sistem nasıl çalışır";
$lang['155'] = "Bu yazı bizim kullanıcı topluluğu tarafından işaretlenmiş, bazı kullanıcılar için uygun olmayan içeriğe sahip olabilir.";
$lang['156'] = "görüntülemek için Güvenli Mod kapatın";
$lang['157'] = "1 saniye önce";
$lang['158'] = "Saniye önce";
$lang['159'] = "1 dakika önce";
$lang['160'] = "dakika önce";
$lang['161'] = "1 saat önce";
$lang['162'] = "saat önce";
$lang['163'] = "gün önce";
$lang['164'] = "gün önce";
$lang['165'] = "Yorum";
$lang['166'] = "Yeni";
$lang['167'] = "Eski";
$lang['168'] = "A Boss gibi kullanın ".$config[website_name]."";
$lang['169'] = "İpucu";
$lang['170'] = "basın' J 've' hızlı mesaj gezinmek için K 'tuşları.";
$lang['171'] = "İpucu-Basın-2";
$lang['172'] = "Sıcak";
$lang['173'] = "Trend";
$lang['174'] = "Oy";
$lang['175'] = "Ooops Siz Oy sayfasını görüntülemek için uygun değilsiniz!.";
$lang['176'] = "Sadece ".$config[website_name]."ers sayfasını görüntülemek için izin verilir, ".$config[website_name]." mesajların kalitesini korumak için.";
$lang['177'] = "Bu ".$config[website_name]." nasıl çalıştığını öğrenmek için okumak";
$lang['178'] = "ve";
$lang['179'] = "hemen kaydolun!";
$lang['180'] = "sevmemezlik";
$lang['181'] = "sadece bir metin mesajı, orjinal mesaj bir mem ya da öfke yüz (örneğin kötü değil, B * tch Lütfen, GTFO, Yabancılar ...). Append ETMEYİN Onlar sayılmaz konum olarak mesaj yok [Sabit] ve silinecektir. ";
$lang['182'] = "Eğer bir mesaj varsa veya orijinal mesajları kabul etmiyorsanız, yorum yapın görüş bildirmektir.";
$lang['183'] = "Hata:. Varolmayan düzeltmek için çalışın yazılan";
$lang['184'] = "Adım 1:";
$lang['185'] = "sağ tıklayın ve bilgisayarınıza görüntü kaydetmek";
$lang['186'] = "Adım 2:";
$lang['187'] = "Fix it ve upload";
$lang['188'] = "Hata:. Bugün için, yarın yeniden deneyin upload alıntı ulaşmıştır";
$lang['189'] = "Arama";
$lang['190'] = "aramak için anahtar kelimeleri girin";
$lang['191'] = "Sonuç bulunamadı";
$lang['192'] = "Mesajlar";
$lang['193'] = "Sevdikleri";
$lang['194'] = "Mesajlar";
$lang['195'] = "Bir şey söyle";
$lang['196'] = "Shuffle";
$lang['197'] = "Giriş";
$lang['198'] = "Çıkış";
$lang['199'] = "Yükle";
$lang['200'] = "Hızlı";
$lang['201'] = "Fun";
$lang['202'] = "Yardım";
$lang['203'] = "Kullanım Koşulları";
$lang['204'] = "Gizlilik Politikası";
$lang['205'] = "İletişim";
$lang['206'] = "Raporu";
$lang['207'] = "Neden bu yazılan rapor ediyorsunuz?";
$lang['208'] = "bir marka veya telif hakkı ihlali içerir";
$lang['209'] = "Spam, bariz bir reklam veya talep";
$lang['210'] = "rahatsız edici materyaller / çıplaklık içeriyor";
$lang['211'] = "Başka bir post Repost";
$lang['212'] = "Gönder";
$lang['213'] = "".$config[website_name]." Klavye Kısayolları";
$lang['214'] = "rastgele";
$lang['215'] = "Yorum";
$lang['216'] = "nefret";
$lang['217'] = "sonraki";
$lang['218'] = "önceki";
$lang['219'] = "gibi";
$lang['220'] = "kapatmak için herhangi bir yere tıklayın";
$lang['221'] = "Update";
$lang['222'] = "Diller";
$lang['223'] = "Dil seçin";
$lang['224'] = "Hata: Oturum açılamadı";
$lang['225'] = "Hata:. Hesabınız etkin değil";
$lang['226'] = "Bizimle iletişime geçmeden önce, bizim SSS bakabilirsiniz.";
$lang['227'] = "Konu";
$lang['228'] = "Seç";
$lang['229'] = "Bir hata bildir";
$lang['230'] = "soru sor";
$lang['231'] = "Yorum Gönder";
$lang['232'] = "İş sorgulama";
$lang['233'] = "Konu";
$lang['234'] = "Tek cümleyle İsteğiniz.";
$lang['235'] = "Mesaj";
$lang['236'] = "size daha fazla ayrıntı, bize yardım etmek için daha kolay.";
$lang['237'] = "Adınız";
$lang['238'] = "E";
$lang['239'] = "Size ulaşabileceğimiz bir e-posta.";
$lang['240'] = "Sizin OS";
$lang['241'] = "örneğin Windows 7, Mac OS X Lion";
$lang['242'] = "Code";
$lang['243'] = "Hata: bir konu seçiniz";
$lang['244'] = "Hata: Lütfen bir konu girin";
$lang['245'] = "Hata: Lütfen mesajınızı girin";
$lang['246'] = "Hata: Lütfen adınızı girin";
$lang['247'] = "Hata:. yanlış Resim kodu, lütfen tekrar deneyin";
$lang['248'] = "Başarı:. Mesajınız gönderildi";
$lang['249'] = "".$config[website_name]." İletişim Formu";
$lang['250'] = "Bir kullanıcı sadece çevrimiçi iletişim formu ile aşağıdaki bilgileri göndermek etti:";
$lang['251'] =  "Recommended";
$lang['252'] =  "Sign up with Twitter";
$lang['253'] =  "Please enter your email to finish registration.";
$lang['254'] =  "en";
$lang['255'] =  "LTR";
$lang['256'] =  "Sign in with Twitter";
$lang['257'] =  "Hello,";
$lang['258'] =  "Thumb View";
$lang['259'] =  "List View";
$lang['260'] =  "Top Users";
$lang['261'] =  "Previous";
$lang['262'] =  "Next";
$lang['263'] =  "Sorry, but fixing gags is currently disabled";
$lang['264'] =  "There's something wrong with this gag, please report it via our contact form";
$lang['265'] =  "Finish Registration";
$lang['266'] =  "Awwwwwwww Yeah!";
$lang['267'] =  "You've done that! Your post is shown on the&nbsp;<a href=\"/vote\" target=\"_blank\">Vote</a>&nbsp;page. Now get more votes by sharing the fun with your friends!";
$lang['268'] =  "Paste link in <b>email</b> or <b>IM</b>";
$lang['269'] =  "Channel";
$lang['270'] =  "Please select post channel";
$lang['271'] =  "Choose the closest Channel/Category to your post";
$lang['272'] =  "Top Channels";
$lang['273'] =  "";
?>